#ifndef EX3_SORTER_H
#define EX3_SORTER_H

#define STRING_MAX_LENGTH 100
#define _GNU_SOURCE
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "ex3_ll.h"

void sorter(char* argv[]);
#endif
