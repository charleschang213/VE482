#ifndef FUNCS_H
#define FUNCS_H
#include <unistd.h>
#include <stdio.h>
const char *pwd();
void cd(const char *dir);
#endif
